
package sistema_gym;

/**
 *
 * @author ivani
 */
public class Login2 {
      public static void main(String[] args) {
          Login lo=new Login();
          lo.setVisible(true);
      }
    
}
