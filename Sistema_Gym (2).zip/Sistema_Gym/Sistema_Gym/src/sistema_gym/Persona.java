
package sistema_gym;

/**
 *
 * @author ivani
 */
public abstract class Persona {
    
}
