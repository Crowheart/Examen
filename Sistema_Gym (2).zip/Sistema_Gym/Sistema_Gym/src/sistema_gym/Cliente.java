
package sistema_gym;

/**
 *
 * @author ivani
 */
public class Cliente extends Persona {
    
}
