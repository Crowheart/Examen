
package sistema_gym;

/**
 *
 * @author ivani
 */
public class Empleado extends Persona {
    
}
