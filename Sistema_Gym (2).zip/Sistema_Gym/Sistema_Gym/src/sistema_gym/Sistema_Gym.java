
package sistema_gym;

/**
 *
 * @author ivani
 */
public class Sistema_Gym {
    public static void main(String[] args) {
        // TODO code application logic here
        Login lo = new Login();
    lo.setVisible(true);
        
    }
    
}
